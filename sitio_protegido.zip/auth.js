document.addEventListener("DOMContentLoaded", function () {
  const claveCorrecta = "cargaxpress2025";
  const intento = prompt("Introduce la clave para acceder al sitio:");

  if (intento === claveCorrecta) {
    document.getElementById("contenido").style.display = "block";
  } else {
    document.body.innerHTML = "<h2>Acceso denegado. Clave incorrecta.</h2>";
  }
});
